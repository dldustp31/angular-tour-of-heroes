import { Hero } from './hero';

export const HEROES: Hero[] = [
  { id: 1, name: 'Yeonse Rhee' },
  { id: 2, name: 'Fiorella Silva' },
  { id: 3, name: 'Daniel Revay' },
  { id: 4, name: 'Linley Mancilla' }
];